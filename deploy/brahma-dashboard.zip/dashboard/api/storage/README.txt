Runtime data (sessions, logs, backups). Must be writable by PHP (chmod 755/775). Blocked from the web by .htaccess.
